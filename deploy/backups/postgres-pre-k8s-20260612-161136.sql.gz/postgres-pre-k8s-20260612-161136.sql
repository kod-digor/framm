--
-- PostgreSQL database dump
--

\restrict iCgAgwV6uDnvV15LY3wPZIPjS2Ds3jSvEfeFUFIq2AHNv6ANshfvWOfbaaq1rL0

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DomainStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DomainStatus" AS ENUM (
    'PENDING_DNS',
    'VERIFIED',
    'ACTIVE'
);


--
-- Name: OrganizationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrganizationStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'BUREAU',
    'ASSOC_ADMIN',
    'ASSOC_MEMBER'
);


--
-- Name: WalletTransactionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WalletTransactionType" AS ENUM (
    'DEPOSIT',
    'CONSUMPTION',
    'RECHARGE'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "actorId" text,
    "organizationId" text,
    action text NOT NULL,
    target text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Domain; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Domain" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    fqdn text NOT NULL,
    status public."DomainStatus" DEFAULT 'PENDING_DNS'::public."DomainStatus" NOT NULL,
    "dnsRecordsJson" jsonb,
    "stalwartDomainId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: EmailAlias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailAlias" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    source text NOT NULL,
    destination text NOT NULL,
    "stalwartAliasId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Mailbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Mailbox" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    "domainId" text NOT NULL,
    address text NOT NULL,
    "stalwartAccountId" text,
    "quotaBytes" bigint DEFAULT 1073741824 NOT NULL,
    "usedBytes" bigint DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Organization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    presentation text NOT NULL,
    status public."OrganizationStatus" DEFAULT 'PENDING'::public."OrganizationStatus" NOT NULL,
    "rejectReason" text,
    "approvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "walletBalanceCents" integer DEFAULT 0 NOT NULL
);


--
-- Name: OrganizationMember; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OrganizationMember" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "organizationId" text NOT NULL,
    role public."UserRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PlatformPricing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PlatformPricing" (
    id text NOT NULL,
    sku text NOT NULL,
    region text NOT NULL,
    "storageEurPerGbHour" double precision NOT NULL,
    "storageEurPerGbMonth" double precision NOT NULL,
    source text NOT NULL,
    "fetchedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: UsageSnapshot; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UsageSnapshot" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    metric text NOT NULL,
    value bigint NOT NULL,
    "recordedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."UserRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: WalletTransaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WalletTransaction" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    type public."WalletTransactionType" NOT NULL,
    "amountCents" integer NOT NULL,
    "feeCents" integer DEFAULT 0 NOT NULL,
    "balanceAfterCents" integer NOT NULL,
    "monthKey" text,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, "actorId", "organizationId", action, target, metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: Domain; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Domain" (id, "organizationId", fqdn, status, "dnsRecordsJson", "stalwartDomainId", "createdAt", "updatedAt") FROM stdin;
cmqawjf3q0005it4j4e8n42d7	org_kod_digor	kod-digor.bzh	VERIFIED	[{"name": "kod-digor.bzh", "type": "MX", "value": "10 mail.kod-digor.bzh."}, {"name": "kod-digor.bzh", "type": "TXT", "value": "v=spf1 mx -all"}]	\N	2026-06-12 12:27:46.358	2026-06-12 12:27:46.358
\.


--
-- Data for Name: EmailAlias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EmailAlias" (id, "organizationId", source, destination, "stalwartAliasId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Mailbox; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Mailbox" (id, "organizationId", "domainId", address, "stalwartAccountId", "quotaBytes", "usedBytes", "createdAt", "updatedAt") FROM stdin;
cmqawx2jp0001it0ghssy7ib1	org_kod_digor	cmqawjf3q0005it4j4e8n42d7	contact@kod-digor.bzh	contact@kod-digor.bzh	1073741824	0	2026-06-12 12:38:23.269	2026-06-12 12:38:23.269
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Organization" (id, name, slug, presentation, status, "rejectReason", "approvedAt", "createdAt", "updatedAt", "walletBalanceCents") FROM stdin;
org_kod_digor	Kod Digor	kod-digor	Association hébergeuse de la plateforme Framm.	APPROVED	\N	2026-06-12 10:01:24.606	2026-06-12 10:01:24.606	2026-06-12 10:01:24.606	0
cmqaypvlh0003itm1pinvldad	Hoari	hoari-1781270926900	Association pour la création de concerts chez l'habitant.	REJECTED	Doublon	\N	2026-06-12 13:28:46.902	2026-06-12 13:34:41.78	0
cmqaypv280000itm11r6444kb	Hoari	hoari-1781270926207	Association pour la création de concerts chez l'habitant.	APPROVED	\N	2026-06-12 13:37:52.444	2026-06-12 13:28:46.208	2026-06-12 13:37:52.535	960
\.


--
-- Data for Name: OrganizationMember; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."OrganizationMember" (id, "userId", "organizationId", role, "createdAt") FROM stdin;
mig_cmqaqc06t0000sb0t9c4b81rk	cmqaqc06t0000sb0t9c4b81rk	org_kod_digor	BUREAU	2026-06-12 12:33:33.739
cmqaypv280002itm1gqzfdyil	cmqaqc06t0000sb0t9c4b81rk	cmqaypv280000itm11r6444kb	ASSOC_ADMIN	2026-06-12 13:28:46.208
cmqaypvlh0005itm1jvzfz3wk	cmqaqc06t0000sb0t9c4b81rk	cmqaypvlh0003itm1pinvldad	ASSOC_ADMIN	2026-06-12 13:28:46.902
\.


--
-- Data for Name: PlatformPricing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PlatformPricing" (id, sku, region, "storageEurPerGbHour", "storageEurPerGbMonth", source, "fetchedAt") FROM stdin;
cmqax9pnm0000ito9z8bkqatc	/storage/obj/usage-new-gen-bucket-standard/fr-par	fr-par	2.2e-05	0.01606	scaleway_public_catalog	2026-06-12 12:48:13.091
cmqax9po20001ito97lvy9ezf	/storage/obj/usage-new-gen-bucket-standard/fr-par	fr-par	2.2e-05	0.01606	scaleway_public_catalog	2026-06-12 12:48:13.106
cmqax9qce0002ito9oqa185op	/storage/obj/usage-new-gen-bucket-standard/fr-par	fr-par	2.2e-05	0.01606	scaleway_public_catalog	2026-06-12 12:48:13.983
cmqax9qv00003ito9egxtq3rk	/storage/obj/usage-new-gen-bucket-standard/fr-par	fr-par	2.2e-05	0.01606	scaleway_public_catalog	2026-06-12 12:48:14.652
\.


--
-- Data for Name: UsageSnapshot; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UsageSnapshot" (id, "organizationId", metric, value, "recordedAt") FROM stdin;
cmqaseny20000p70tp6tk487o	org_kod_digor	STORAGE_BYTES	0	2026-06-12 10:32:06.074
cmqaseny20001p70tvrf8yj76	org_kod_digor	MAILBOX_COUNT	0	2026-06-12 10:32:06.074
cmqaseny20002p70trl6gje4r	org_kod_digor	DOMAIN_COUNT	0	2026-06-12 10:32:06.074
cmqasgjip0000p70tualkucnv	org_kod_digor	STORAGE_BYTES	0	2026-06-12 10:33:33.649
cmqasgjip0001p70txkrfberm	org_kod_digor	MAILBOX_COUNT	0	2026-06-12 10:33:33.649
cmqasgjip0002p70txsl0x0th	org_kod_digor	DOMAIN_COUNT	0	2026-06-12 10:33:33.649
cmqasn2qx0000ob0tfpnbouv5	org_kod_digor	STORAGE_BYTES	0	2026-06-12 10:38:38.506
cmqasn2qx0001ob0tk6cgkiwf	org_kod_digor	MAILBOX_COUNT	0	2026-06-12 10:38:38.506
cmqasn2qx0002ob0tmi5d11sd	org_kod_digor	DOMAIN_COUNT	0	2026-06-12 10:38:38.506
cmqauwkuf0000qo0tefuu0wpc	org_kod_digor	STORAGE_BYTES	0	2026-06-12 11:42:01.095
cmqauwkuf0001qo0tfflhw5ja	org_kod_digor	MAILBOX_COUNT	0	2026-06-12 11:42:01.095
cmqauwkuf0002qo0tqh8qwv31	org_kod_digor	DOMAIN_COUNT	0	2026-06-12 11:42:01.095
cmqav37zp0000mp0t91s7g4ht	org_kod_digor	STORAGE_BYTES	0	2026-06-12 11:47:11.029
cmqav37zp0001mp0tcx1l6sdv	org_kod_digor	MAILBOX_COUNT	0	2026-06-12 11:47:11.029
cmqav37zp0002mp0t86gmaw0o	org_kod_digor	DOMAIN_COUNT	0	2026-06-12 11:47:11.029
cmqavu91c0000lh0tntyhxuva	org_kod_digor	STORAGE_BYTES	0	2026-06-12 12:08:12.097
cmqavu91c0001lh0tkrkzqeew	org_kod_digor	MAILBOX_COUNT	0	2026-06-12 12:08:12.097
cmqavu91c0002lh0tlbvx88qs	org_kod_digor	DOMAIN_COUNT	0	2026-06-12 12:08:12.097
cmqaxkt0s0000s40tfih2nls3	org_kod_digor	STORAGE_BYTES	0	2026-06-12 12:56:50.465
cmqaxkt0s0001s40tl1iiah8k	org_kod_digor	MAILBOX_COUNT	1	2026-06-12 12:56:50.465
cmqaxkt0s0002s40tri84fv11	org_kod_digor	DOMAIN_COUNT	1	2026-06-12 12:56:50.465
cmqazq07v0000li0tud12qqcw	org_kod_digor	STORAGE_BYTES	0	2026-06-12 13:56:52.273
cmqazq07v0001li0tx3ozbu1b	org_kod_digor	MAILBOX_COUNT	1	2026-06-12 13:56:52.273
cmqazq07v0002li0t14spbc09	org_kod_digor	DOMAIN_COUNT	1	2026-06-12 13:56:52.273
cmqazq08i0003li0t02m1o0mu	cmqaypv280000itm11r6444kb	STORAGE_BYTES	0	2026-06-12 13:56:52.273
cmqazq08i0004li0thgh82r51	cmqaypv280000itm11r6444kb	MAILBOX_COUNT	0	2026-06-12 13:56:52.273
cmqazq08i0005li0trltsvc7e	cmqaypv280000itm11r6444kb	DOMAIN_COUNT	0	2026-06-12 13:56:52.273
cmqb022on0000li0ts5g0ckxe	org_kod_digor	STORAGE_BYTES	0	2026-06-12 14:06:15.292
cmqb022on0001li0ttxu1a4zc	org_kod_digor	MAILBOX_COUNT	1	2026-06-12 14:06:15.292
cmqb022on0002li0tyh3jyvoj	org_kod_digor	DOMAIN_COUNT	1	2026-06-12 14:06:15.292
cmqb022sm0003li0t252ve5ei	cmqaypv280000itm11r6444kb	STORAGE_BYTES	0	2026-06-12 14:06:15.292
cmqb022sm0004li0tcacgnuem	cmqaypv280000itm11r6444kb	MAILBOX_COUNT	0	2026-06-12 14:06:15.292
cmqb022sm0005li0tfe94q0ee	cmqaypv280000itm11r6444kb	DOMAIN_COUNT	0	2026-06-12 14:06:15.292
cmqb0379s0000li0thumohk5t	org_kod_digor	STORAGE_BYTES	0	2026-06-12 14:07:07.914
cmqb0379s0001li0thc1l9yll	org_kod_digor	MAILBOX_COUNT	1	2026-06-12 14:07:07.914
cmqb0379s0002li0t7yscxyi2	org_kod_digor	DOMAIN_COUNT	1	2026-06-12 14:07:07.914
cmqb037c90003li0tc73n64b7	cmqaypv280000itm11r6444kb	STORAGE_BYTES	0	2026-06-12 14:07:07.914
cmqb037c90004li0tsb82sjmh	cmqaypv280000itm11r6444kb	MAILBOX_COUNT	0	2026-06-12 14:07:07.914
cmqb037c90005li0twdsyb9im	cmqaypv280000itm11r6444kb	DOMAIN_COUNT	0	2026-06-12 14:07:07.914
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, "passwordHash", role, "createdAt", "updatedAt") FROM stdin;
cmqaqc06t0000sb0t9c4b81rk	igor@mages.pro	$2a$12$V31IdXiScoKmqW8CyENQtuJW92fVYZACUG0qhVi0DvDmxHe6W/onK	BUREAU	2026-06-12 09:34:02.742	2026-06-12 10:01:24.606
\.


--
-- Data for Name: WalletTransaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WalletTransaction" (id, "organizationId", type, "amountCents", "feeCents", "balanceAfterCents", "monthKey", description, "createdAt") FROM stdin;
cmqaz1kmx0007itm1t5kbbhx8	cmqaypv280000itm11r6444kb	DEPOSIT	1000	40	960	\N	Frais d'inscription — solde initial	2026-06-12 13:37:52.569
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
b7d4a7fd-c4ff-4e8e-95b1-eb5fccd8739f	09edff34ead2f51eff4fd7285507d85b78550f6e8ab8788bb09f1b64f1034a33	2026-06-12 09:33:37.771586+00	20250612000000_init	\N	\N	2026-06-12 09:33:37.683761+00	1
c95780aa-c1dd-4568-a769-43f388df0d8e	2b30f5c3e33d133e35ebfcd506a29080f5485e08f02da158b82058557b5127ee	2026-06-12 12:33:33.70714+00	20250612150000_multitenant	\N	\N	2026-06-12 12:33:33.56926+00	1
89cc3725-3307-49db-94bd-653c73a7a441	f98d49cb30c31238c3fefa6cec919d7b352ac507d7f2ffbce2bb93d90030ff34	2026-06-12 12:43:27.205644+00	20250612160000_platform_pricing	\N	\N	2026-06-12 12:43:27.090176+00	1
ad93ca0c-7ee4-4ac6-b53a-cf52235d1e8d	15706d3e869ae9dbdc0c205318a1fac75f5a5fc6845718c8c57473bfe5e2b9b7	2026-06-12 13:17:25.717576+00	20250612170000_wallet	\N	\N	2026-06-12 13:17:25.592147+00	1
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Domain Domain_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_pkey" PRIMARY KEY (id);


--
-- Name: EmailAlias EmailAlias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailAlias"
    ADD CONSTRAINT "EmailAlias_pkey" PRIMARY KEY (id);


--
-- Name: Mailbox Mailbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Mailbox"
    ADD CONSTRAINT "Mailbox_pkey" PRIMARY KEY (id);


--
-- Name: OrganizationMember OrganizationMember_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrganizationMember"
    ADD CONSTRAINT "OrganizationMember_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: PlatformPricing PlatformPricing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PlatformPricing"
    ADD CONSTRAINT "PlatformPricing_pkey" PRIMARY KEY (id);


--
-- Name: UsageSnapshot UsageSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UsageSnapshot"
    ADD CONSTRAINT "UsageSnapshot_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WalletTransaction WalletTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Domain_organizationId_fqdn_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Domain_organizationId_fqdn_key" ON public."Domain" USING btree ("organizationId", fqdn);


--
-- Name: EmailAlias_organizationId_source_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "EmailAlias_organizationId_source_key" ON public."EmailAlias" USING btree ("organizationId", source);


--
-- Name: Mailbox_address_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Mailbox_address_key" ON public."Mailbox" USING btree (address);


--
-- Name: OrganizationMember_userId_organizationId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "OrganizationMember_userId_organizationId_key" ON public."OrganizationMember" USING btree ("userId", "organizationId");


--
-- Name: Organization_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Organization_slug_key" ON public."Organization" USING btree (slug);


--
-- Name: PlatformPricing_fetchedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PlatformPricing_fetchedAt_idx" ON public."PlatformPricing" USING btree ("fetchedAt");


--
-- Name: UsageSnapshot_organizationId_recordedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "UsageSnapshot_organizationId_recordedAt_idx" ON public."UsageSnapshot" USING btree ("organizationId", "recordedAt");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: WalletTransaction_organizationId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WalletTransaction_organizationId_createdAt_idx" ON public."WalletTransaction" USING btree ("organizationId", "createdAt");


--
-- Name: WalletTransaction_organizationId_monthKey_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WalletTransaction_organizationId_monthKey_type_idx" ON public."WalletTransaction" USING btree ("organizationId", "monthKey", type);


--
-- Name: AuditLog AuditLog_actorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Domain Domain_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Domain"
    ADD CONSTRAINT "Domain_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: EmailAlias EmailAlias_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailAlias"
    ADD CONSTRAINT "EmailAlias_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Mailbox Mailbox_domainId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Mailbox"
    ADD CONSTRAINT "Mailbox_domainId_fkey" FOREIGN KEY ("domainId") REFERENCES public."Domain"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Mailbox Mailbox_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Mailbox"
    ADD CONSTRAINT "Mailbox_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: OrganizationMember OrganizationMember_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrganizationMember"
    ADD CONSTRAINT "OrganizationMember_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: OrganizationMember OrganizationMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OrganizationMember"
    ADD CONSTRAINT "OrganizationMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UsageSnapshot UsageSnapshot_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UsageSnapshot"
    ADD CONSTRAINT "UsageSnapshot_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: WalletTransaction WalletTransaction_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WalletTransaction"
    ADD CONSTRAINT "WalletTransaction_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict iCgAgwV6uDnvV15LY3wPZIPjS2Ds3jSvEfeFUFIq2AHNv6ANshfvWOfbaaq1rL0

